﻿using System;

namespace PizzaCalories
{
    public class Engine
    {
        public void Run()
        {

        }
    }
}
