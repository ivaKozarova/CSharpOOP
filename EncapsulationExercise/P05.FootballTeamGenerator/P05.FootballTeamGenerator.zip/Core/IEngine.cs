﻿namespace P05.FootballTeamGenerator.Core
{
    public interface IEngine
    {
        void Run();
    }
}
