﻿namespace P05.FootballTeamGenerator.IO.Contracts
{
    public interface IReadable
    {
        string ReadLine();
    }
}
