﻿namespace BirthdayCelebrations
{
   public interface IBirthdate
    {
        string Name { get; }
        string Birthdate { get; }
    }
}
