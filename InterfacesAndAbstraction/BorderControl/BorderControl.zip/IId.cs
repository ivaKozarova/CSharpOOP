﻿namespace BorderControl
{
    public interface IId
    {
        string Id { get; }
    }
}
