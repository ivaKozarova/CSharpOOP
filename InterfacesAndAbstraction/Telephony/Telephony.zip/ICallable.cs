﻿namespace Telephony
{
    interface ICallable
    {
        string Calling(string input);
        
    }
}
