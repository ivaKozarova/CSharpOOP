﻿namespace WildFarm.Contracts
{
    public interface ISoundProducable
    {
        string ProduceSound();
    }
}
