﻿namespace WildFarm.IO.Contacts
{
   public  interface IReadable
    {
        string ReadLine();
    }
}
