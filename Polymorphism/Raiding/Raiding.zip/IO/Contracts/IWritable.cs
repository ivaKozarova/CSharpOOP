﻿namespace Raiding.IO.Contracts
{
    public interface IWritable
    {
        void WriteLine(string text);
        void Write(string text);
    }
}
