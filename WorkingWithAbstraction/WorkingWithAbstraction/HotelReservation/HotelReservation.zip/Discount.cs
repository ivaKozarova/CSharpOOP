﻿namespace HotelReservation
{
    public enum Discount
    {
        None = 0,
        SecondVisit = 10,
        VIP = 20
    }
}
